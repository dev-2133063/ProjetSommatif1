﻿namespace projet.Security.Authorization
{
    public class Roles
    {
        public const string Admin = "admin";
        public const string User = "user";
        public const string Editor = "editor";
    }
}
